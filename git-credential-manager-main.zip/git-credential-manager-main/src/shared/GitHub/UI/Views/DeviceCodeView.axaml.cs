using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace GitHub.UI.Views
{
    public partial class DeviceCodeView : UserControl
    {
        public DeviceCodeView()
        {
            InitializeComponent();
        }
    }
}
