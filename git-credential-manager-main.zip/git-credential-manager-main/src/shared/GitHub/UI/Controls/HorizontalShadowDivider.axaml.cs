using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace GitHub.UI.Controls
{
    public partial class HorizontalShadowDivider : UserControl
    {
        public HorizontalShadowDivider()
        {
            InitializeComponent();
        }
    }
}
